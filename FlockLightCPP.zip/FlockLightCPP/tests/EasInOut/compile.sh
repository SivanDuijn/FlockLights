g++ main.cpp -lsfml-graphics -lsfml-window -lsfml-system
./a.out
