g++ main.cpp ../../Utils/Utils.cpp -lsfml-graphics -lsfml-window -lsfml-system
./a.out
