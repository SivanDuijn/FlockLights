g++ -c Utils/ws2812-rpi.cpp -o Utils/ws2812-rpi.o -fpermissive

cd Flocking
./compile.sh
cd ..