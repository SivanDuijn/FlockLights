// just a thing for putting all cpp files in one file
#include "Boid.cpp"
#include "BoidUtils.cpp"
#include "Flock.cpp"